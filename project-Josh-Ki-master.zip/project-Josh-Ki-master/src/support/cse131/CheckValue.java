package support.cse131;

public interface CheckValue {
	
	public boolean check(String s);

}
